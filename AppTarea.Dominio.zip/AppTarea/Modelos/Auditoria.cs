﻿namespace AppTarea
{
    public class Auditoria
    {
        public DateTime Creado { get; set; }
        public String CreadoPor { get; set; }
        public DateTime Actualizado { get; set; }
        public String ActualizadoPor { get; set; }
    }
}
