﻿namespace AppTarea.Dominio.Response
{
    public class APIResponse
    {
        public int Code { get; set; }
        public int Status { get; set; }
        public String? Mensaje { get; set; }
    }
}
