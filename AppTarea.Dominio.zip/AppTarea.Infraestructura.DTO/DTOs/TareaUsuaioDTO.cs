﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AppTarea.Infraestructura.DTO.DTOs
{
    public class TareaUsuaioDTO
    {
        public Guid tareaId { get; set; }
        public Guid usuarioId { get; set; }
       
    }
}
